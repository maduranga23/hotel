(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();
    
    
    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";
    
    $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });
    
    
    // Back to top button
 


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        margin: 25,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            }
        }
    });
    
})(jQuery);

function changeDestination() {
    var selectElement = document.getElementById("select1");
    var selectedValue = selectElement.value;
    var imageElement = document.getElementById("destination-image");
    var textElement = document.getElementById("destination-text");

    if (selectedValue === "1") {
        imageElement.src = "./img/destination-1.jpg"; 
        textElement.innerHTML = "<h5 class='mb-3'>Lanka Hotel Colombo</h5><p class='text-body mb-0'>Feel an irrepressible wave of excitement as you have the best surfing experience, set to the backdrop of serenity, and pristine blue waters.</p><a class='btn btn-sm btn-primary' href=''>Discover more</a>";
    } else if (selectedValue === "2") {
        imageElement.src = "./img/destination-2.jpg";
        textElement.innerHTML = "<h5 class='mb-3'>Lanka Hotel Kandy</h5><p class='text-body mb-0'>Experience affordable rustic barefoot type elegance, which is designed to reflect the rural environs and simplicity of the local village life surrounded by rich biodiversity.<a class='btn btn-sm btn-primary' href=''>Discover more</a>";
    } 
}

$(document).ready(function() {
    stylePreloader();
});

function stylePreloader() {
    if ($('.preloader').length) {
        $('.preloader').delay(200).fadeOut(500);
    }
}



$(document).ready(function () {
    $('#startDate, #endDate').on('change.datetimepicker', function (e) {
        var startDate = $('#startDate').datetimepicker('date');
        var endDate = $('#endDate').datetimepicker('date');

        if (startDate && endDate) {
            var diffTime = Math.abs(endDate - startDate);
            var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
            $('#numNights').text(diffDays + " nights");
        } else {
            $('#numNights').text("0 nights");
        }
    });
    $('.datetimepicker-input').datetimepicker({
        format: 'DD/MM/YYYY', // Set the format of the displayed date
        useCurrent: false,
        icons: {
            time: 'fa fa-clock',
            date: 'fa fa-calendar',
            up: 'fa fa-chevron-up',
            down: 'fa fa-chevron-down',
            previous: 'fa fa-chevron-left',
            next: 'fa fa-chevron-right',
            today: 'fa fa-crosshairs',
            clear: 'fa fa-trash',
            close: 'fa fa-times'
        }
    });
});

$(document).ready(function () {
    // Get today's date
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
    var yyyy = today.getFullYear();
    
    // Format today's date as DD/MM/YYYY
    today = dd + '/' + mm + '/' + yyyy;

    // Set the placeholder of the input field to today's date
    $('#startDate').attr('placeholder', today);
    $('#endDate').attr('placeholder', today);
});

